#!/bin/bash
mkdir -p bin
javac -verbose -d bin src/utils/*.java src/*.java

