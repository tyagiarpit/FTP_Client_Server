#!/bin/bash
java -cp bin Simple_ftp_server $*

